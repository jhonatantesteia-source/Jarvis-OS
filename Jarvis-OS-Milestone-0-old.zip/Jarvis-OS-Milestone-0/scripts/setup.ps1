$ErrorActionPreference = "Stop"
py -3.13 -m venv .venv
& ".venv\Scripts\python.exe" -m pip install --upgrade pip
& ".venv\Scripts\python.exe" -m pip install -r requirements.txt
if (-not (Test-Path ".env")) { Copy-Item ".env.example" ".env" }
npm install
Write-Host "JARVIS OS foundation installed."
